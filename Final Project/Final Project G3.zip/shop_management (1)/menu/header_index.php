<header>
		<a href="/shop_management (1)/shop_management/home.html" class="logo"><span>R</span>estora <span>G</span>rocery</a>
		<ul class="navigation">
			<li><a href="/shop_management (1)/shop_management/home.html">Home</a></li>
			<li><a href="#about">About</a></li>
			<li><a href="/shop_management (1)/shop_management/service.php">Service</a></li>
			<li><a href="/shop_management (1)/shop_management/login.php">Login</a></li>
			<li><a href="/shop_management (1)/shop_management/registration.php">Registration</a></li>
			<li><a href="/shop_management (1)/shop_management/mycart.php">My Cart</a></li>
					
		</ul>
	</header>