<header>
		<a href="home.html" class="logo"><span>R</span>estora <span>G</span>rocery</a>
		<ul class="navigation">
			<li><a href="home.html">Home</a></li>
			<li><a href="#about">About</a></li>
			<li><a href="service.php">Service</a></li>
			<li><a href="login.php">Login</a></li>
			<li><a href="registration.php">Registration</a></li>
			<li><a href="mycart.php">My Cart</a></li>		
		</ul>
	</header>
