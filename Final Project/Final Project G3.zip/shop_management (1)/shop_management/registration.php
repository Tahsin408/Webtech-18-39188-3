<?php  
 $message = '';  
 $error = '';  
 if(isset($_POST["submit"]))  
 {  
      if(empty($_POST["name"]))  
      {  
           $error = "<label class='text-danger'>Enter Name</label>";  
      }
      else if(empty($_POST["email"]))  
      {  
           $error = "<label class='text-danger'>Enter an e-mail</label>";  
      }  
      else if(empty($_POST["un"]))  
      {  
           $error = "<label class='text-danger'>Enter a username</label>";  
      }  
      else if(empty($_POST["pass"]))  
      {  
           $error = "<label class='text-danger'>Enter a password</label>";  
      }
      else if(empty($_POST["Cpass"]))  
      {  
           $error = "<label class='text-danger'>Confirm password field cannot be empty</label>";  
      } 
      else if(empty($_POST["gender"]))  
      {  
           $error = "<label class='text-danger'>Gender cannot be empty</label>";  
      } 
       
      else  
      {  
           if(file_exists('Rdata.json'))  
           {  
                $current_data = file_get_contents('Rdata.json');  
                $array_data = json_decode($current_data, true);  
                $extra = array(  
                     'name'               =>     $_POST['name'],  
                     'e-mail'          =>     $_POST["email"],  
                     'username'     =>     $_POST["un"],  
                     'gender'     =>     $_POST["gender"],  
                     'dob'     =>     $_POST["dob"]  
                );  
                $array_data[] = $extra;  
                $final_data = json_encode($array_data);  
                if(file_put_contents('Rdata.json', $final_data))  
                {  
                     $message = "<label class='text-success'>File Appended Success fully</p>";  
                }  
           }  
           else  
           {  
                $error = 'JSON File not exits';  
           }  
      }  
 }  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="home.css">
  <title>registration</title> 
           <style type="text/css">
  th{
    border: 1px solid #F0F8FF;
    text-align: right;
    padding: 8px;
  }
  </style> 
            
      </head>  
      <body>

      <header>
          <a href="home.html" class="logo">R</span>estora <span>G</span>rocery</a>
          <ul class="navigation">
               <!-- 
               <li><a href="#about">About</a></li>
               <li><a href="#service">Service</a></li>
               <li><a href="login.php">Login</a></li> -->
               <li><a href="home.html">Home</a></li>
               <li><a href="login.php">Login</a></li>
               
               
          </ul>
     </header>

        <section class="registration" id="registration">
          <div class="title">
              <h2 class="titleText">Registrat<span>i</span>on</h2>
      
          </div>

          
        
  
           <br />  



            <div class="titlereg">   
            <table cellpadding="10" cellpadding="10" align="center">            
                <form method="post">  
                     <?php   
                     if(isset($error))  
                     {  
                          echo $error;  
                     }  
                     ?>  
                     <br />
                     <tr>
                     <th>NAME</th><td><input type="text" name="name" class="form-control"></td>
                     </tr> 
                     <tr>
                       <th>USERNAME</th><td><input type="text" name = "un" class="form-control" /></td>
                     </tr>
                     <tr>
                     <th>Email</th><td><input type="text" name="email" class="form-control"></td>
                     </tr>
                     <tr>
                     <th>PASSWORD</th><td><input type="password" name="pass" class="form-control"></td>
                     </tr>
                     <tr>
                     <th>CONFIRM PASSWORD</th><td><input type="password" name="Cpass" class="form-control"></td>
                     </tr>
                     <tr>
                       <th>GENDER</th><td><input type="radio" id="male" name="gender" value="male">
                     <label for="male">Male</label>                     
                     <input type="radio" id="female" name="gender" value="female">
                     <label for="female">Female</label>
                     <input type="radio" id="other" name="gender" value="other">
                     <label for="other">Other</label><br>
                     </td>
                     </tr>
                     <tr>
                     <th>DATE OF BIRTH</th><td><input type="date" name="dob"></td>
                     </tr>
                     <tr>
                       <th></th><td><input type="submit" name="submit" value="Append" class="btn btn-info" </td>
                     </tr>
                      
                                        
                     <?php  
                     if(isset($message))  
                     {  
                          echo $message;  
                     }  
                     ?>  
                </form>

              </table>

                </div>
      </section>
            
           <br /> 
                  
                     
            
           



      </body>  
 </html>  