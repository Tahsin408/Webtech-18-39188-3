<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="home.css">

	<title>SHOP MANAGEMENT</title>
</head>

<body>
	<?php include 'header.php';?>
	
	<section class="service" id="service">
		<div class="title">
			<h2 class="titleText">Serv<span>i</span>ce</h2>
			
		</div>
		<br>
		<br>
		<br>
		<div class="content">
			<div class="box">
				<div class="imgBx">
					<img src="image/img_vegetable.jpg" height="190" width="300">
					
				</div>
				<div class="text">
					<h3><a href="vegetable.php" class="btn">Vegetables</a></h3>
					
				</div>
				
			</div>
			<div class="box">
				<div class="imgBx">
					<img src="image/juice.jpg" height="190" width="300">
					
				</div>
				<div class="text">
					<h3><a href="juice.php" class="btn">JUICE</a></h3>
					
				</div>
				
			</div>
			<div class="box">
				<div class="imgBx">
					<img src="image/meat.jpg"  height="190" width="300">
					
				</div>
				<div class="text">
					<h3><a href="meat.php" class="btn">MEAT</a></h3>
					
				</div>
				
			</div>
			<div class="box">
				<div class="imgBx">
					<img src="image/chicken.jpg"  height="190" width="300">
					
				</div>
				<div class="text">
					<h3><a href="chicken.php" class="btn">CHICKEN</a></h3>
					
				</div>
				
			</div>
			<div class="box">
				<div class="imgBx">
					<img src="image/snack.jpg"   height="190" width="300">
					
				</div>
				<div class="text">
					<h3><a href="snack.php" class="btn">SNACK</a></h3>
					
				</div>
				
			</div>
			<div class="box">
				<div class="imgBx">
					<img src="image/dryfood.jpg"  height="190" width="300">
					
				</div>
				<div class="text">
					<h3><a href="dryfood.php" class="btn">DRY FOOD</a></h3>
					
				</div>
				
			</div>
			<div class="box">
				<div class="imgBx">
					<img src="image/fish.jpg"   height="190" width="300">
					
				</div>
				<div class="text">
					<h3><a href="fish.php" class="btn">FISH</a></h3>
					
				</div>
				
			</div>
			<div class="box">
				<div class="imgBx">
					<img src="image/frozeenfood.jpg"  height="190" width="300" >
					 
					
				</div>
				<div class="text">
					<h3><a href="frozenfood.php" class="btn">FROZEN FOOD</a></h3>
					
				</div>
				
			</div>
			
		</div>
		
	</section>
	

	<script type="text/javascript">
		window.addEventListener('scroll', function(){
			const header = document.querySelector('header');
			header.classList.toggle("sticky", window.scrollY > 0);
		});
	</script>
	<?php include 'footer.php';?>
</body>
</html>