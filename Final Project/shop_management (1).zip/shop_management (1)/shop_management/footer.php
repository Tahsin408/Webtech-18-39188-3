<style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: #E5E4E2;
  color: #00008B;
  text-align: center;
}
</style>

<div class="footer">
  <p>Healthy Food At Your Doorstep<br></br>© grocery.com 2021 All Rights Reserved</p>
</div>